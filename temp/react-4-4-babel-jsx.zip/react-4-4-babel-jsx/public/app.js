var greeter = require('./components/Greeter');

greeter();
